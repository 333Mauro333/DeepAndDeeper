﻿using SFML.Graphics;
using SFML.System;
using SFML.Window;
using SFML_TEST;
using System;

namespace Big_Block_Breaker
{
    class Gameplay : Scene
    {
        Random random = new Random();

        Player player;
        Enemy octopus;
        Enemy shark;

        Enemy octopus2;
        Enemy octopus3;

        Enemy shark2;

        Sprite back;
        Sprite rocksLeft1;
        Sprite rocksLeft2;
        Sprite rocksLeft3;
        Sprite rocksLeft4;
        Sprite rocksRight1;
        Sprite rocksRight2;
        Sprite rocksRight3;
        Sprite rocksRight4;
        Sprite plantsLeft1;
        Sprite plantsLeft2;
        Sprite plantsRight1;
        Sprite plantsRight2;

        Statistics statistics;

        Item[] bubble = new Item[5];
        Item coin = new Item(1, 400, 700);

        Item[] littleCoins = new Item[10];

        float points = 0;

        float speedPlants = 50;

        bool appearLvl2 = false;
        bool appearLvl3 = false;

        bool endGame = false;

        COLLISION_DIRECTION CollisionDir;

        public override void Init()
        {
            back = new Sprite(new Texture("resources/Backgrounds/background.png"));
            back.Scale *= 3;
            rocksLeft1 = new Sprite(new Texture("resources/Backgrounds/rocksLeft.png"));
            rocksLeft2 = new Sprite(new Texture("resources/Backgrounds/rocksLeft.png"));
            rocksLeft3 = new Sprite(new Texture("resources/Backgrounds/rocksLeft.png"));
            rocksLeft4 = new Sprite(new Texture("resources/Backgrounds/rocksLeft.png"));
            rocksLeft1.Scale *= 1.5f;
            rocksLeft2.Scale *= 1.5f;
            rocksLeft3.Scale *= 1.5f;
            rocksLeft4.Scale *= 1.5f;

            rocksRight1 = new Sprite(new Texture("resources/Backgrounds/rocksRight.png"));
            rocksRight2 = new Sprite(new Texture("resources/Backgrounds/rocksRight.png"));
            rocksRight3 = new Sprite(new Texture("resources/Backgrounds/rocksRight.png"));
            rocksRight4 = new Sprite(new Texture("resources/Backgrounds/rocksRight.png"));
            rocksRight1.Scale *= 1.5f;
            rocksRight2.Scale *= 1.5f;
            rocksRight3.Scale *= 1.5f;
            rocksRight4.Scale *= 1.5f;

            plantsLeft1 = new Sprite(new Texture("resources/Backgrounds/plantsLeft.png"));
            plantsLeft2 = new Sprite(new Texture("resources/Backgrounds/plantsLeft.png"));
            plantsRight1 = new Sprite(new Texture("resources/Backgrounds/plantsRight.png"));
            plantsRight2 = new Sprite(new Texture("resources/Backgrounds/plantsRight.png"));

            rocksLeft2.Position = new Vector2f(0.0f, 439.5f);
            rocksLeft3.Position = new Vector2f(0.0f, 879.0f);
            rocksLeft4.Position = new Vector2f(0.0f, 1318.5f);

            rocksRight1.Position = new Vector2f(749.0f, -300.0f);
            rocksRight2.Position = new Vector2f(749.0f, 139.5f);
            rocksRight3.Position = new Vector2f(749.0f, 579.0f);
            rocksRight4.Position = new Vector2f(749.0f, 1018.5f);

            plantsLeft2.Position = new Vector2f(0.0f, 1185.0f);
            plantsRight1.Position = new Vector2f(710.0f, -600);
            plantsRight2.Position = new Vector2f(710.0f, 585);

            player = new Player(Keyboard.Key.W, Keyboard.Key.S, Keyboard.Key.A, Keyboard.Key.D, 400, 300);
            player.InitAnimation();

            octopus = new Enemy(0, 600, 600, 2, 400, false, player);
            octopus.InitAnimation();

            shark = new Enemy(1, 900, 500, 1, 400, false, player);
            shark.InitAnimation();

            statistics = new Statistics();
            statistics.InitStatistics();

            coin.InitAnimation();
            int posY = 900;

            for (int i = 0; i < bubble.Length; i++)
            {
                switch (i)
                {
                    case 0:
                        bubble[i] = new Item(0, 200, 800, 100);
                        break;

                    case 1:
                        bubble[i] = new Item(0, 500, 600, 100);
                        break;

                    case 2:
                        bubble[i] = new Item(0, 350, 200, 50);
                        break;

                    case 3:
                        bubble[i] = new Item(0, 550, 750, 25);
                        break;

                    case 4:
                        bubble[i] = new Item(0, 50, 400, 150);
                        break;
                }

                bubble[i].InitAnimation();
            }
            for (int i = 0; i < littleCoins.Length; i++)
            {
                switch (i)
                {
                    case 0:
                        littleCoins[i] = new Item(2, 400, posY, 125);
                        break;

                    case 1:
                        littleCoins[i] = new Item(2, 370, posY, 125);
                        break;

                    case 2:
                        littleCoins[i] = new Item(2, 340, posY, 125);
                        break;

                    case 3:
                        littleCoins[i] = new Item(2, 310, posY, 125);
                        break;

                    case 4:
                        littleCoins[i] = new Item(2, 280, posY, 125);
                        break;

                    case 5:
                        littleCoins[i] = new Item(2, 250, posY, 125);
                        break;

                    case 6:
                        littleCoins[i] = new Item(2, 220, posY, 125);
                        break;

                    case 7:
                        littleCoins[i] = new Item(2, 250, posY, 125);
                        break;

                    case 8:
                        littleCoins[i] = new Item(2, 280, posY, 125);
                        break;

                    case 9:
                        littleCoins[i] = new Item(2, 310, posY, 125);
                        break;
                }

                posY += 50;

                littleCoins[i].InitAnimation();
            }
        }
        public override void Udpate(float deltaTime)
        {
            if (player.GetHealth() > 0)
            {
                points += 0.005f;
            }
            else
            {
                endGame = true;
                Achievements.totalDistance += statistics.GetDistance();
                statistics.ResetValues();
            }

            if (Achievements.totalDistance >= 1000)
            {
                Achievements.done[0] = true;
            }
            if (Achievements.leaveOctopus >= 20)
            {
                Achievements.done[1] = true;
            }
            if (Achievements.money >= 500)
            {
                Achievements.done[2] = true;
            }

            if (statistics.GetDistance() > 75.0f && !appearLvl2)
            {
                appearLvl2 = true;
                octopus2 = new Enemy(0, 600, 600, 2, 400, false, player);
                octopus2.InitAnimation();

                octopus3 = new Enemy(0, 600, 600, 2, 400, false, player);
                octopus3.InitAnimation();
            }
            if (statistics.GetDistance() > 100.0f && !appearLvl3)
            {
                appearLvl3 = true;
                shark2 = new Enemy(1, 900, 500, 1, 400, false, player);
                shark2.InitAnimation();
            }

            CollisionsOnGamePlay();

            coin.Update(deltaTime);
            coin.UpdateAnimation(deltaTime);

            for (int i = 0; i < littleCoins.Length; i++)
            {
                littleCoins[i].Update(deltaTime);
                littleCoins[i].UpdateAnimation(deltaTime);

                ControlItemEscape(littleCoins[i]);
            }

            MoveBackground(deltaTime);

            statistics.UpdatePoints(player.GetHealth(), points);

            player.Update(deltaTime);
            player.UpdateAnimation(deltaTime);

            if (player.GetRenderer().Position.X < rocksLeft1.Position.X + rocksLeft1.GetGlobalBounds().Width * 1.25f)
            {
                player.GetRenderer().Position = new Vector2f(rocksLeft1.Position.X + rocksLeft1.GetGlobalBounds().Width * 1.25f, player.GetRenderer().Position.Y);
            }
            else if (player.GetRenderer().Position.X > rocksRight1.Position.X)
            {
                player.GetRenderer().Position = new Vector2f(rocksRight1.Position.X, player.GetRenderer().Position.Y);
            }

            octopus.Update(deltaTime);
            octopus.UpdateAnimation(deltaTime);

            shark.Update(deltaTime);
            shark.UpdateAnimation(deltaTime);

            if (octopus.GetHit())
            {
                statistics.SetShineHealth();
            }

            ControlEnemyEscape(octopus);
            ControlEnemyEscape(shark);
            ControlItemEscape(coin);

            if (octopus2 != null)
            {
                octopus2.Update(deltaTime);
                octopus2.UpdateAnimation(deltaTime);
                ControlEnemyEscape(octopus2);
            }
            if (octopus3 != null)
            {
                octopus3.Update(deltaTime);
                octopus3.UpdateAnimation(deltaTime);
                ControlEnemyEscape(octopus3);
            }
            if (shark2 != null)
            {
                shark2.Update(deltaTime);
                shark2.UpdateAnimation(deltaTime);
                ControlEnemyEscape(shark2);
            }

            if (player.GetRenderer().Position.Y < 35.0f)
            {
                player.GetRenderer().Position = new Vector2f(player.GetRenderer().Position.X, 35.0f);
            }
            if (player.GetRenderer().Position.Y > 580.0f)
            {
                player.GetRenderer().Position = new Vector2f(player.GetRenderer().Position.X, 580.0f);
            }
        }
        public override void Draw(RenderWindow window)
        {
            window.Draw(back);

            player.DrawAnimation(window);
            coin.DrawAnimation(window);
            for (int i = 0; i < littleCoins.Length; i++)
            {
                littleCoins[i].DrawAnimation(window);
            }
            octopus.DrawAnimation(window);
            if (octopus2 != null)
            {
                octopus2.DrawAnimation(window);
            }
            if (octopus3 != null)
            {
                octopus3.DrawAnimation(window);
            }
            shark.DrawAnimation(window);
            if (shark2 != null)
            {
                shark2.DrawAnimation(window);
            }
            window.Draw(rocksLeft1);
            window.Draw(rocksLeft2);
            window.Draw(rocksLeft3);
            window.Draw(rocksLeft4);
            window.Draw(rocksRight1);
            window.Draw(rocksRight2);
            window.Draw(rocksRight3);
            window.Draw(rocksRight4);

            window.Draw(plantsLeft1);
            window.Draw(plantsLeft2);
            window.Draw(plantsRight1);
            window.Draw(plantsRight2);

            for (int i = 0; i < bubble.Length; i++)
            {
                bubble[i].DrawAnimation(window);
            }

            statistics.DrawStatistics(window);
        }
        public override void KeyPressed(Keyboard.Key key)
        {
            player.KeyPressed(key);

        }
        public override void KeyReleased(Keyboard.Key key)
        {
            player.KeyReleased(key);
        }


        void MoveBackground(float deltaTime)
        {
            for (int i = 0; i < bubble.Length; i++)
            {
                bubble[i].Update(deltaTime);
                bubble[i].UpdateAnimation(deltaTime);
                UpBubble(bubble[i]);
            }

            back.Position += new Vector2f(0.0f, -0.5f);

            GoUpBackElements(deltaTime);

            UpPlants(plantsLeft1);
            UpPlants(plantsLeft2);
            UpPlants(plantsRight1);
            UpPlants(plantsRight2);

            UpRocks(rocksLeft1);
            UpRocks(rocksLeft2);
            UpRocks(rocksLeft3);
            UpRocks(rocksLeft4);
            UpRocks(rocksRight1);
            UpRocks(rocksRight2);
            UpRocks(rocksRight3);
            UpRocks(rocksRight4);
        }
        void GoUpBackElements(float deltaTime)
        {
            plantsLeft1.Position += new Vector2f(0.0f, -speedPlants) * deltaTime;
            plantsLeft2.Position += new Vector2f(0.0f, -speedPlants) * deltaTime;
            plantsRight1.Position += new Vector2f(0.0f, -speedPlants) * deltaTime;
            plantsRight2.Position += new Vector2f(0.0f, -speedPlants) * deltaTime;

            rocksLeft1.Position += new Vector2f(0.0f, -speedPlants) * deltaTime;
            rocksLeft2.Position += new Vector2f(0.0f, -speedPlants) * deltaTime;
            rocksLeft3.Position += new Vector2f(0.0f, -speedPlants) * deltaTime;
            rocksLeft4.Position += new Vector2f(0.0f, -speedPlants) * deltaTime;
            rocksRight1.Position += new Vector2f(0.0f, -speedPlants) * deltaTime;
            rocksRight2.Position += new Vector2f(0.0f, -speedPlants) * deltaTime;
            rocksRight3.Position += new Vector2f(0.0f, -speedPlants) * deltaTime;
            rocksRight4.Position += new Vector2f(0.0f, -speedPlants) * deltaTime;
        }
        void UpPlants(Sprite plants)
        {
            if (plants.Position.Y < -1184.0f)
            {
                plants.Position += new Vector2f(0.0f, 2378);
            }
        }
        void UpRocks(Sprite rocks)
        {
            if (rocks.Position.Y < -439.5f)
            {
                rocks.Position += new Vector2f(0.0f, 1758.0f);
            }
        }
        void UpBubble(Item bubble)
        {
            if (bubble.GetRenderer().Position.Y < -200.0f)
            {
                bubble.GetBubbleSound().Play();
                int tempNum = random.Next(7);
                bubble.GetRenderer().Position += new Vector2f(0.0f, 1000);
                bubble.SetNewPositionX(tempNum);
            }
        }

        void ControlEnemyEscape(Enemy enemy)
        {
            if (EnemyOutOfScreen(enemy))
            {
                enemy.ResetValues();
                enemy.ActiveEnemy();
            }
        }
        void ControlItemEscape(Item item)
        {
            if (item.GetRenderer().Position.Y < -100)
            {
                item.ResetValues();
                item.ActiveItem();
            }
        }
        bool EnemyOutOfScreen(Enemy enemy)
        {
            if (enemy.GetBoxCollision().Position.X < -150)
            {
                return true;
            }
            else if (enemy.GetBoxCollision().Position.X > 950)
            {
                return true;
            }
            else if (enemy.GetBoxCollision().Position.Y > 750)
            {
                return true;
            }
            else if (enemy.GetBoxCollision().Position.Y < -150)
            {
                return true;
            }

            return false;
        }


        void CollisionsOnGamePlay()
        {
            if (ColisionUtils.CheckCollision(player.GetBoxCollision(), octopus.GetBoxCollision(), ref CollisionDir))
            {
                octopus.OnPlayerCollision(CollisionDir);
            }
            if (ColisionUtils.CheckCollision(player.GetBoxCollision(), shark.GetBoxCollision(), ref CollisionDir))
            {
                if (!shark.GetEscape())
                {
                    statistics.SetShineHealth();
                }
                shark.OnPlayerCollision(CollisionDir);
            }
            if (ColisionUtils.CheckCollision(player.GetBoxCollision(), coin.GetRenderer(), ref CollisionDir))
            {
                if (!coin.GetTaken())
                {
                    points += coin.GetValuePoints();
                    Achievements.money += coin.GetValuePoints();
                }
                coin.OnPlayerCollision(CollisionDir);
            }

            for (int i = 0; i < littleCoins.Length; i++)
            {
                if (ColisionUtils.CheckCollision(player.GetBoxCollision(), littleCoins[i].GetRenderer(), ref CollisionDir))
                {
                    if (!littleCoins[i].GetTaken())
                    {
                        points += littleCoins[i].GetValuePoints();
                        Achievements.money += littleCoins[i].GetValuePoints();
                    }
                    littleCoins[i].OnPlayerCollision(CollisionDir);
                }
            }

            if (octopus2 != null)
            {
                if (ColisionUtils.CheckCollision(player.GetBoxCollision(), octopus2.GetBoxCollision(), ref CollisionDir))
                {
                    octopus2.OnPlayerCollision(CollisionDir);
                }
            }
            if (octopus3 != null)
            {
                if (ColisionUtils.CheckCollision(player.GetBoxCollision(), octopus3.GetBoxCollision(), ref CollisionDir))
                {
                    octopus3.OnPlayerCollision(CollisionDir);
                }
            }
            if (shark2 != null)
            {
                if (ColisionUtils.CheckCollision(player.GetBoxCollision(), shark2.GetBoxCollision(), ref CollisionDir))
                {
                    if (!shark2.GetEscape())
                    {
                        statistics.SetShineHealth();
                    }
                    shark2.OnPlayerCollision(CollisionDir);
                }
            }
        }
    }
}
