﻿using SFML.Graphics;
using SFML.System;
using SFML.Window;
using SFML.Audio;
using SFML_TEST;
using System;

namespace Big_Block_Breaker
{
    class Item
    {
        Random random = new Random();

        Sprite renderer;

        Sprite spr_normal;
        Sprite spr_taken;
        
        Animation anim_normal;
        Animation anim_taken;

        Sound snd_taken;

        int typeOfItem = 0;
        int valuePoints = 10;

        float posX = 0;
        float posY = 0;
        float speedY = 0;

        bool active = true;
        bool taken = false;

        SPRITE state;

        enum SPRITE { NORMAL, TAKEN };

        public Item(int typeOfItem, float posX, float posY, float speedY = 200)
        {
            // 0 = bubble
            switch (typeOfItem)
            {
                case 0:
                    snd_taken = new Sound(new SoundBuffer("resources/Sfx/bubble.ogg"));

                    spr_normal = new Sprite(new Texture("resources/Backgrounds/bubble.png"));
                    spr_normal.Origin = new Vector2f(50.0f, 50.0f);

                    spr_taken = new Sprite(new Texture("resources/Backgrounds/bubble.png"));
                    spr_taken.Origin = new Vector2f(50.0f, 50.0f);
                    break;

                case 1:
                    snd_taken = new Sound(new SoundBuffer("resources/Sfx/coin.ogg"));

                    spr_normal = new Sprite(new Texture("resources/Sprites/Items/coin.png"));
                    spr_normal.Origin = new Vector2f(16.0f, 16.0f);

                    spr_taken = new Sprite(new Texture("resources/Sprites/Items/takenCoin.png"));
                    spr_taken.Origin = new Vector2f(16.0f, 16.0f);

                    valuePoints = 25;
                    break;

                case 2:
                    snd_taken = new Sound(new SoundBuffer("resources/Sfx/little_coin.ogg"));

                    spr_normal = new Sprite(new Texture("resources/Sprites/Items/littleCoin.png"));
                    spr_normal.Origin = new Vector2f(16.0f, 16.0f);

                    spr_taken = new Sprite(new Texture("resources/Sprites/Items/takenLittleCoin.png"));
                    spr_taken.Origin = new Vector2f(16.0f, 16.0f);

                    valuePoints = 10;
                    break;
            }

            renderer = spr_taken;
            renderer.Position = new Vector2f(posX, posY);

            state = SPRITE.NORMAL;

            this.typeOfItem = typeOfItem;
            this.speedY = speedY;
        }

        public void Update(float deltaTime)
        {
            if (active)
            {
                renderer.Position += new Vector2f(0.0f, -speedY) * deltaTime;
            }
        }

        #region Getters and setters

        public Sprite GetRenderer()
        {
            return renderer;
        }
        public bool GetTaken()
        {
            return taken;
        }
        public int GetValuePoints()
        {
            return valuePoints;
        }
        public Sound GetBubbleSound()
        {
            return snd_taken;
        }

        public void SetNewPositionX(float randomNum)
        {
            switch (randomNum)
            {
                case 0:
                    renderer.Position = new Vector2f(25.0f, renderer.Position.Y);
                    break;

                case 1:
                    renderer.Position = new Vector2f(100.0f, renderer.Position.Y);
                    break;

                case 2:
                    renderer.Position = new Vector2f(225.0f, renderer.Position.Y);
                    break;

                case 3:
                    renderer.Position = new Vector2f(400.0f, renderer.Position.Y);
                    break;

                case 4:
                    renderer.Position = new Vector2f(550.0f, renderer.Position.Y);
                    break;

                case 5:
                    renderer.Position = new Vector2f(700.0f, renderer.Position.Y);
                    break;

                case 6:
                    renderer.Position = new Vector2f(825.0f, renderer.Position.Y);
                    break;
            }
        }

        #endregion

        public void ResetValues()
        {
            active = false;
            InitAnimation();
            SpriteNormal();
        }
        public void ActiveItem()
        {
            int choice = random.Next(20);
            int posX = 0;
            int posY = 750;

            switch (typeOfItem)
            {
                case 1:
                case 2:
                    switch (choice)
                    {
                        case 0:
                            posX = 35;
                            break;

                        case 1:
                            posX = 70;
                            break;

                        case 2:
                            posX = 105;
                            break;

                        case 3:
                            posX = 140;
                            break;

                        case 4:
                            posX = 175;
                            break;

                        case 5:
                            posX = 210;
                            break;

                        case 6:
                            posX = 245;
                            break;

                        case 7:
                            posX = 280;
                            break;

                        case 8:
                            posX = 315;
                            break;

                        case 9:
                            posX = 350;
                            break;

                        case 10:
                            posX = 385;
                            break;

                        case 11:
                            posX = 385;
                            break;

                        case 12:
                            posX = 420;
                            break;

                        case 13:
                            posX = 455;
                            break;

                        case 14:
                            posX = 490;
                            break;

                        case 15:
                            posX = 525;
                            break;

                        case 16:
                            posX = 560;
                            break;

                        case 17:
                            posX = 595;
                            break;

                        case 18:
                            posX = 630;
                            break;

                        case 19:
                            posX = 675;
                            break;

                        case 20:
                            posX = 710;
                            break;

                        case 21:
                            posX = 745;
                            break;
                    }

                    active = true;
                    renderer.Position = new Vector2f(posX, posY);
                    taken = false;
                    break;
            }
        }

        public void InitAnimation()
        {
            int Left = 0;
            double speed = 0.075;

            switch (typeOfItem)
            {
                case 0:
                    speed = 0.75;

                    anim_normal = new Animation(ref spr_normal, Animation.MODE.LOOP);
                    for (int i = 0; i < 5; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 100, 100), 0.0));
                                break;
                            case 1:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 100, 100), speed));
                                break;
                            case 2:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 100, 100), speed));
                                break;
                            case 3:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 100, 100), speed));
                                break;
                            case 4:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 100, 100), speed));
                                break;
                        }

                        Left += 100;
                    }
                    Left = 0;

                    anim_taken = new Animation(ref spr_taken, Animation.MODE.LOOP);
                    for (int i = 0; i < 5; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 100, 100), 0.0));
                                break;
                            case 1:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 100, 100), speed));
                                break;
                            case 2:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 100, 100), speed));
                                break;
                            case 3:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 100, 100), speed));
                                break;
                            case 4:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 100, 100), speed));
                                break;
                        }

                        Left += 200;
                    }
                    break;

                case 1:
                    speed = 0.075;

                    anim_normal = new Animation(ref spr_normal, Animation.MODE.LOOP);
                    for (int i = 0; i < 17; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 1:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 2:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 3:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 4:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 5:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 6:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 7:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 8:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 9:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 10:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 11:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 12:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 13:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 14:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 15:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 16:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                        }

                        Left += 32;
                    }
                    Left = 0;

                    anim_taken = new Animation(ref spr_taken, Animation.MODE.ONCE);
                    for (int i = 0; i < 9; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 1:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 2:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 3:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 4:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 5:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 6:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 7:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 8:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                        }

                        Left += 32;
                    }
                    break;

                case 2:
                    speed = 0.06;

                    anim_normal = new Animation(ref spr_normal, Animation.MODE.LOOP);
                    for (int i = 0; i < 17; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 1:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 2:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 3:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 4:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 5:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 6:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 7:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 8:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 9:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 10:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 11:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 12:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 13:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 14:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 15:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 16:
                                anim_normal.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                        }

                        Left += 32;
                    }
                    Left = 0;

                    anim_taken = new Animation(ref spr_taken, Animation.MODE.ONCE);
                    for (int i = 0; i < 9; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 1:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 2:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 3:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 4:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 5:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 6:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 7:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                            case 8:
                                anim_taken.AddFrame(new Frame(new IntRect(Left, 0, 32, 32), speed));
                                break;
                        }

                        Left += 32;
                    }
                    break;
            }

            SpriteNormal();
        }
        public void UpdateAnimation(float elapsed)
        {
            switch (state)
            {
                case SPRITE.NORMAL:
                    anim_normal.Update(elapsed);
                    break;

                case SPRITE.TAKEN:
                    anim_taken.Update(elapsed);
                    break;
            }
        }
        public void DrawAnimation(RenderWindow window)
        {
            switch (state)
            {
                case SPRITE.NORMAL:
                    window.Draw(spr_normal);
                    break;

                case SPRITE.TAKEN:
                    window.Draw(spr_taken);
                    break;
            }
        }

        #region Sprite modifier

        void SpriteNormal()
        {
            state = SPRITE.NORMAL;
            spr_normal.Position = renderer.Position;
            renderer = spr_normal;
        }
        void SpriteTaken()
        {
            state = SPRITE.TAKEN;
            spr_taken.Position = renderer.Position;
            renderer = spr_taken;
        }

        #endregion


        public void OnPlayerCollision(COLLISION_DIRECTION dir)
        {
            switch (dir)
            {
                case COLLISION_DIRECTION.TOP:
                case COLLISION_DIRECTION.BOT:
                case COLLISION_DIRECTION.LEFT:
                case COLLISION_DIRECTION.RIGHT:
                    if (!taken)
                    {
                        if (typeOfItem == 1)
                        {

                        }
                        else if (typeOfItem == 2)
                        {
                            Achievements.money++;
                        }

                        snd_taken.Play();
                        taken = true;
                        SpriteTaken();
                    }
                    break;
            }
        }
    }
}