﻿using Big_Block_Breaker;
using SFML.Graphics;
using SFML.System;
using SFML.Window;
using System;
using System.ComponentModel;

namespace SFML_TEST
{
    class Game
    {
        public static Game instance;
        //Variables que tiene que tener:

        private Clock clock;          // Tiempo.
        private RenderWindow window;  // Ventana.
        public static uint width = 800;
        public static uint height = 600;
        public Game()
        {
            instance = this;   
            const string windowTitle = ("THE DEPTH"); // Título de la ventana.
            VideoMode videoMode = new VideoMode(width, height); // Para inicializar la ventana con sus medidas.
            
            window = new RenderWindow(videoMode, windowTitle); // La ventana misma con la info escrita arriba.
            window.SetFramerateLimit(60); // Subimágenes por segundo.

            window.SetKeyRepeatEnabled(false);
            window.Closed += OnWindowClosed;
            window.KeyPressed += OnKeyPressed;
            window.KeyReleased += OnKeyReleased;

            clock = new Clock();
        }

        public void Run()
        {
            SceneManager.LoadScene(new Menu());
            
            while (window.IsOpen)
            {
                Udpate();
                Draw();
            }
        }

        public RenderWindow GetWindow()
        {
            return window;
        }

        private void Udpate()
        {
            Time time = clock.Restart(); // Tiempo

            SceneManager.GetCurrentScene().Udpate(time.AsSeconds()); // Obtener la escena, pasándole el time.

            window.DispatchEvents(); //Eventos a evaluar.
        }

        private void Draw()
        {
            window.Clear(Color.Black); // Se limpia la pantalla

            SceneManager.GetCurrentScene().Draw(window); // Se llama a la escena actual para poder dibujarla

            window.Display(); // Se muestra todo
        }

        private static void OnWindowClosed(object sender, EventArgs e) // Para poder cerrar la ventana.
        {
            Window window = (Window)sender;
            window.Close();
        }

        private static void OnKeyPressed(object sender, KeyEventArgs e) // Eventos de presionado.
        {
            if (e.Code == Keyboard.Key.Escape)
            {
                Window window = (Window)sender;
                window.Close();
            }
            else
            {
                SceneManager.GetCurrentScene().KeyPressed(e.Code);
            }
        }

        private static void OnKeyReleased(object sender, KeyEventArgs e) // Eventos de soltado
        {
            if (e.Code == Keyboard.Key.Escape)
            {
                Window window = (Window)sender;
                window.Close();
            }
            else
            {
                SceneManager.GetCurrentScene().KeyReleased(e.Code);
            }
        }
    }
}
