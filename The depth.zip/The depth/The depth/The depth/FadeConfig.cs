﻿using SFML.System;

namespace SFML_TEST
{
    static class FadeConfig
    {
        public static int Contador = 0;
        public static void InitFade(FadeInFadeOut[] fadein)
        {
            int PositionX = 0;
            int PositionY = 0;
            for (int i = 0; i < fadein.Length; i++)
            {
                fadein[i] = new FadeInFadeOut(0);
                fadein[i].SetPositions(PositionX, PositionY);

                if (i == 5 || i == 11 || i == 17 || i == 23 || i == 29)
                {
                    PositionX = 0;
                    PositionY += 100;
                }
                else
                {
                    PositionX += 150;
                }
            }
        }

        public static void GetAnimation(FadeInFadeOut[] fadein, float deltaTime)
        {
            for (int i = 0; i < fadein.Length; i++)
            {
                fadein[i].GetAnimation(deltaTime);
            }
        }

        public static void InitFadeOut(FadeInFadeOut[] fadeout)
        {
            int PositionX = 0;
            int PositionY = 0;

            for (int i = 0; i < fadeout.Length; i++)
            {
                fadeout[i] = new FadeInFadeOut(1);
                fadeout[i].SetPositions(PositionX, PositionY);

                if (i == 5 || i == 11 || i == 17 || i == 23 || i == 29)
                {
                    PositionX = 0;
                    PositionY += 100;
                }
                else
                {
                    PositionX += 150;
                }
            }
        }

        public static void StartFadeOut(FadeInFadeOut[] fadeout, float deltaTime, int Scene, bool Set0) // booleano para scorelevel
        {
            Contador++;
            if (Contador == 10)
            {
                for (int i = 0; i < fadeout.Length; i++)
                {
                    fadeout[i].LoadAnimation(fadeout[i].GetTexture(), fadeout[i].GetRenderer());
                }
            }
            else if (Contador == 71) // Booleano acá
            {
                MusicManager.timer = new Time();
                Contador = 0;

                if (Set0)
                {
                    MusicManager.StopMusicScore();
                }

                // HACER SWITCH CON "int Scene" PARA LA CARGA DE ESCENA
            }

            if (Contador >= 10)
            {
                for (int i = 0; i < fadeout.Length; i++)
                {
                    fadeout[i].GetAnimation(deltaTime);
                }
            }
        }
    }
}
