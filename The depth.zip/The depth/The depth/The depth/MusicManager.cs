﻿using SFML.System;
using SFML.Audio;
using System;

namespace SFML_TEST
{
    static class MusicManager
    {
        static Random random = new Random();
        public static int NumTrack = 0;
        public static bool Go = true;

        static Music track0 = new Music("resources/Tracks/Track0.ogg");

        public static Time timer = new Time();

        static Music musica = new Music("resources/Tracks/LevelPassed.ogg");
        static Music track1 = new Music("resources/Tracks/Track1.ogg");
        static Music track2 = new Music("resources/Tracks/Track2.ogg");
        static Music track3 = new Music("resources/Tracks/Track3.ogg");
        static Music track4 = new Music("resources/Tracks/Track4.ogg");
        static Music track5 = new Music("resources/Tracks/Track5.ogg");

        static bool End = true;

        public static void SongInMenu()
        {
            if (Go)
            {
                track0.Play();
                Go = false;
            }
        }

        static void RandomTracksList1()
        {
            if (End)
            {
                NumTrack = random.Next(5);
                GetTrackInGame(NumTrack).Play();
                End = false;
            }

            if (!End)
            {
                if (timer >= GetTrackInGame(NumTrack).Duration)
                {
                    GetTrackInGame(NumTrack).Stop();
                    timer = new Time();
                    NumTrack = random.Next(5);
                    End = true;
                }
            }
        }

        public static Music GetTrackInGame(int NumTrack)
        {
            switch (NumTrack)
            {
                case 0:
                    return track1;
                case 1:
                    return track2;
                case 2:
                    return track3;
                case 3:
                    return track4;
                default:
                    return track5;
            }
        }

        public static void PlayRandomMusic1(float deltaTime)
        {
            timer += Time.FromSeconds(deltaTime);
            RandomTracksList1();
        }

        public static void StopMenuMusic()
        {
            Go = true;
            track0.Stop();
        }

        public static void StopRandomMusic()
        {
            GetTrackInGame(NumTrack).Stop();
            End = true;
        }

        public static void SetSettingsOfTracks()
        {
            track0.Volume = 45.0f;
            track1.Volume = 40.0f;
            track2.Volume = 25.0f;
            track3.Volume = 30.0f;
            track4.Volume = 30.0f;
            track5.Volume = 30.0f;
            musica.Volume = 35.0f;
        }

        public static void PlayMusicScore()
        {
            musica.Play();
        }
        public static void StopMusicScore()
        {
            musica.Stop();
        }
    }
}
