﻿using SFML.Audio;
using SFML.Graphics;
using SFML.System;
using SFML.Window;
using System;

namespace Big_Block_Breaker
{
    class Statistics
    {
        float points = 0;
        int health = 0;
        static float distance = 10;

        int counter = 0;

        bool shine = false;

        Text txt_points;
        Text txt_health;
        Text txt_distance;


        public void InitStatistics()
        {
            Font font = new Font("resources/Fonts/retro.ttf");

            txt_points = new Text(points.ToString(), font);
            txt_points.CharacterSize = 25;
            txt_points.Position = new Vector2f(50.0f, 19.0f);
            txt_points.FillColor = Color.White;

            txt_health = new Text(points.ToString(), font);
            txt_health.CharacterSize = 25;
            txt_health.Position = new Vector2f(315.0f, 19.0f);
            txt_health.FillColor = Color.White;

            txt_distance = new Text(distance.ToString(), font);
            txt_distance.FillColor = Color.White;
            txt_distance.CharacterSize = 25;
            txt_distance.Position = new Vector2f(550.0f, 19.0f);
        }
        public void UpdatePoints(int health = 100, float points = 0)
        {
            ShiningHealth();

            if (health > 0)
            {
                distance += 0.035f;
                this.points = points;
                this.points += 0.005f;
            }

            string CurrPoints = "";
            CurrPoints += "POINTS: ";
            CurrPoints += points.ToString("00000");
            txt_points.DisplayedString = CurrPoints;

            string CurrHealth = "";
            CurrHealth += "HEALTH: ";
            CurrHealth += health.ToString("0");
            txt_health.DisplayedString = CurrHealth;

            string CurrDepth = "";
            CurrDepth += "DEPTH: ";
            CurrDepth += distance.ToString("0.0");
            CurrDepth += " M";
            txt_distance.DisplayedString = CurrDepth;
        }
        public void DrawStatistics(RenderWindow window)
        {
            window.Draw(txt_points);
            window.Draw(txt_health);
            window.Draw(txt_distance);
        }

        public float GetDistance()
        {
            return distance;
        }
        public void SetShineHealth()
        {
            shine = true;
        }
        public void ResetValues()
        {
            distance = 0;
            points = 0;
        }
        void ShiningHealth()
        {
            if (shine)
            {
                counter++;

                switch (counter)
                {
                    case 0:
                    case 20:
                    case 40:
                    case 60:
                        txt_health.FillColor = Color.Red;
                        break;

                    case 10:
                    case 30:
                    case 50:
                        txt_health.FillColor = Color.White;
                        break;

                    case 70:
                        txt_health.FillColor = Color.White;
                        shine = false;
                        counter = 0;
                        break;
                }
            }
        }
    }
}
