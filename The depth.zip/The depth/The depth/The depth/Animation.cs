﻿using System.Collections.Generic;
using SFML.Graphics;

namespace SFML_TEST
{
    class Frame
    {
        public IntRect rect; // El tamaño del rectángulo que va a tener cada subimagen del sprite.
        public double duration; // El tiempo que va a mostrar cada subimagen del sprite.

        public Frame (IntRect rect, double duration) // Una función (en Animation) llamará a este Frame para establecer
        {                                           // los valores correspondientes en un for.
            this.rect = rect;
            this.duration = duration;
        }
    }

    class Animation
    {
        private List<Frame> frames; // Lista de frames sin límite definido.

        private double progress; 
        private Sprite target;
        private MODE AnimationMode = MODE.LOOP;
        private int ActualFrame = 0;
        public enum MODE {ONCE, LOOP};

        public Animation(ref Sprite target, MODE mode)
        {
            frames = new List<Frame>();
            progress = 0.0f;
            this.target = target;
            AnimationMode = mode;
        }

        public void AddFrame(Frame frame)
        {
            frames.Add(frame);
        }

        public void Update(double elapsed)
        {
            progress += elapsed; // Se suma el tiempo transcurrido ("elapsed" es el deltaTime)

            double p = progress; // variable para usar el valor de progress

            for (int i = 0; i < frames.Count; i++)
            {
                ActualFrame = i;

                p -= frames[i].duration; // Se le resta la duración.

                if (AnimationMode == MODE.LOOP && p > 0.0 && frames[i] == frames[frames.Count - 1]) // Se reinicia
                {
                    i = 0;
                    continue;
                }

                if (p <= 0.0 || frames[i] == frames[frames.Count - 1]) // Se queda quieto
                {
                    target.TextureRect = frames[i].rect;
                    break;
                }
            }
        }       
        public int GetNumberOfFrame()
        {
            return ActualFrame;
        }
    }
}
