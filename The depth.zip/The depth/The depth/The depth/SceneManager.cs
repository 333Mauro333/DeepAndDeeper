﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SFML_TEST
{
    class SceneManager
    {
        private static Scene currentscene = null; // Variable que se va a usar para cargar la escena.

        public static Scene GetCurrentScene() // A la función se la sobrecarga con una variable Scene.
        {
            return currentscene;
        }

        public static void LoadScene(Scene scene) // Se la sobrecarga con la escena que se quiera cargar y la carga.
        {
            currentscene = scene;
            currentscene.Init();
        }
    }
}
