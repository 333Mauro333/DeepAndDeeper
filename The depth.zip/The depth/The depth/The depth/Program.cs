﻿using System;
using SFML.Window;
using SFML.Graphics;
using SFML.System;

namespace SFML_TEST
{
    class Program
    {
        static void Main()
        {
            Game game = new Game();
            game.Run();
        }
    }
}
