﻿using SFML.Graphics;
using SFML.System;
using SFML.Window;
using SFML_TEST;

namespace Big_Block_Breaker
{
    class Player
    {
        Sprite renderer;

        Sprite spr_submarine_left;
        Sprite spr_submarine_right;
        Sprite spr_submarine_destroyed_left;
        Sprite spr_submarine_destroyed_right;

        Sprite boxCollision;

        Animation anim_submarine_left;
        Animation anim_submarine_right;
        Animation anim_submarine_destroyed_left;
        Animation anim_submarine_destroyed_right;

        Keyboard.Key up;
        Keyboard.Key down;
        Keyboard.Key left;
        Keyboard.Key right;

        int health = 100;

        int movesToSetFree = 0;
        int counter = 0;

        float posX = 0;
        float posY = 0;

        float upSpeed = 0;
        float speedX = 250;
        float speedY = 250;

        bool captured = false;

        SPRITE state;

        enum SPRITE { LEFT, RIGHT, DESTROYED_LEFT, DESTROYED_RIGHT };

        public Player(Keyboard.Key up, Keyboard.Key down, Keyboard.Key left, Keyboard.Key right, float posX, float posY)
        {
            boxCollision = new Sprite(new Texture("resources/Sprites/Submarine/boxSubmarine_01.png"));
            boxCollision.Origin = new Vector2f(32.0f, 15.0f);

            spr_submarine_left = new Sprite(new Texture("resources/Sprites/submarineLeft_01.png"));
            spr_submarine_left.Origin = new Vector2f(42.0f, 50.0f);

            spr_submarine_right = new Sprite(new Texture("resources/Sprites/submarineRight_01.png"));
            spr_submarine_right.Origin = new Vector2f(42.0f, 50.0f);

            spr_submarine_destroyed_left = new Sprite(new Texture("resources/Sprites/submarineLeftBroken_01.png"));
            spr_submarine_destroyed_left.Origin = new Vector2f(42.0f, 50.0f);

            spr_submarine_destroyed_right = new Sprite(new Texture("resources/Sprites/submarineRightBroken_01.png"));
            spr_submarine_destroyed_right.Origin = new Vector2f(42.0f, 50.0f);

            renderer = spr_submarine_right;

            state = SPRITE.RIGHT;

            this.up = up;
            this.down = down;
            this.left = left;
            this.right = right;
            this.posX = posX;
            this.posY = posY;

            renderer.Position = new Vector2f(posX, posY);
        }

        public void Update(float deltaTime)
        {
            KeyMaintained(deltaTime);
            boxCollision.Position = renderer.Position;
            if (health < 0)
            {
                health = 0;
            }

            if (health == 0)
            {
                counter++;

                if (counter >= 180)
                {
                    SceneManager.LoadScene(new Menu());
                }
            }
        }

        public void KeyPressed(Keyboard.Key key)
        {
            if (captured)
            {
                if (key == left)
                {
                    movesToSetFree++;
                }
                if (key == right)
                {
                    movesToSetFree++;
                }
                if (key == up)
                {
                    movesToSetFree++;
                }
                if (key == down)
                {
                    movesToSetFree++;
                }
            }
        }
        public void KeyReleased(Keyboard.Key key)
        {

        }
        void KeyMaintained(float deltaTime)
        {
            if (health > 0)
            {
                if (Keyboard.IsKeyPressed(left))
                {
                    renderer.Position += new Vector2f(-speedX, 0.0f) * deltaTime;
                    SpriteLeft();
                }
                if (Keyboard.IsKeyPressed(right))
                {
                    renderer.Position += new Vector2f(speedX, 0.0f) * deltaTime;
                    SpriteRight();
                }
                if (Keyboard.IsKeyPressed(up))
                {
                    renderer.Position += new Vector2f(0.0f, -speedY) * deltaTime;
                }
                if (Keyboard.IsKeyPressed(down))
                {
                    renderer.Position += new Vector2f(0.0f, speedY) * deltaTime;
                }
            }
            else
            {
                renderer.Position += new Vector2f(0.0f, -50.0f) * deltaTime;

                if (state == SPRITE.LEFT)
                {
                    SpriteDestroyedLeft();
                }
                else if (state == SPRITE.RIGHT)
                {
                    SpriteDestroyedRight();
                }
            }
        }

        #region Getters and setters

        public Sprite GetRenderer()
        {
            return renderer;
        }
        public Sprite GetBoxCollision()
        {
            return boxCollision;
        }
        public float GetXposition()
        {
            return renderer.Position.X;
        }
        public float GetYposition()
        {
            return renderer.Position.Y;
        }
        public int GetMoves()
        {
            return movesToSetFree;
        }
        public int GetHealth()
        {
            return health;
        }

        public void SetMoves()
        {
            movesToSetFree = 0;
        }
        public void SetCaptured(bool captured)
        {
            this.captured = captured;
        }
        public void SetModHealth(int health)
        {
            this.health += health;
        }

        #endregion


        public void InitAnimation()
        {
            int Left = 0;

            anim_submarine_left = new Animation(ref spr_submarine_left, Animation.MODE.LOOP);
            for (int i = 0; i < 5; i++)
            {
                switch (i)
                {
                    case 0:
                        anim_submarine_left.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.0));
                        break;
                    case 1:
                        anim_submarine_left.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 2:
                        anim_submarine_left.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 3:
                        anim_submarine_left.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 4:
                        anim_submarine_left.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                }

                Left += 84;
            }

            Left = 0;
            anim_submarine_right = new Animation(ref spr_submarine_right, Animation.MODE.LOOP);
            for (int i = 0; i < 5; i++)
            {
                switch (i)
                {
                    case 0:
                        anim_submarine_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.0));
                        break;
                    case 1:
                        anim_submarine_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 2:
                        anim_submarine_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 3:
                        anim_submarine_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 4:
                        anim_submarine_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                }

                Left += 84;
            }

            Left = 0;
            anim_submarine_destroyed_left = new Animation(ref spr_submarine_destroyed_left, Animation.MODE.LOOP);
            for (int i = 0; i < 7; i++)
            {
                switch (i)
                {
                    case 0:
                        anim_submarine_destroyed_left.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.0));
                        break;
                    case 1:
                        anim_submarine_destroyed_left.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 2:
                        anim_submarine_destroyed_left.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 3:
                        anim_submarine_destroyed_left.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 4:
                        anim_submarine_destroyed_left.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 5:
                        anim_submarine_destroyed_left.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 6:
                        anim_submarine_destroyed_left.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                }

                Left += 84;
            }

            Left = 0;
            anim_submarine_destroyed_right = new Animation(ref spr_submarine_destroyed_right, Animation.MODE.LOOP);
            for (int i = 0; i < 7; i++)
            {
                switch (i)
                {
                    case 0:
                        anim_submarine_destroyed_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.0));
                        break;
                    case 1:
                        anim_submarine_destroyed_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 2:
                        anim_submarine_destroyed_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 3:
                        anim_submarine_destroyed_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 4:
                        anim_submarine_destroyed_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 5:
                        anim_submarine_destroyed_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                    case 6:
                        anim_submarine_destroyed_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                        break;
                }

                Left += 84;
            }
        }
        public void UpdateAnimation(float elapsed)
        {
            switch (state)
            {
                case SPRITE.LEFT:
                    anim_submarine_left.Update(elapsed);
                    break;

                case SPRITE.RIGHT:
                    anim_submarine_right.Update(elapsed);
                    break;

                case SPRITE.DESTROYED_LEFT:
                    anim_submarine_destroyed_left.Update(elapsed);
                    break;

                case SPRITE.DESTROYED_RIGHT:
                    anim_submarine_destroyed_right.Update(elapsed);
                    break;
            }
        }
        public void DrawAnimation(RenderWindow window)
        {
            switch (state)
            {
                case SPRITE.LEFT:
                    window.Draw(spr_submarine_left);
                    break;

                case SPRITE.RIGHT:
                    window.Draw(spr_submarine_right);
                    break;

                case SPRITE.DESTROYED_LEFT:
                    window.Draw(spr_submarine_destroyed_left);
                    break;

                case SPRITE.DESTROYED_RIGHT:
                    window.Draw(spr_submarine_destroyed_right);
                    break;
            }

            //window.Draw(boxCollision);
        }

        #region Sprite modifier

        void SpriteLeft()
        {
            state = SPRITE.LEFT;
            spr_submarine_left.Position = renderer.Position;
            renderer = spr_submarine_left;
        }
        void SpriteRight()
        {
            state = SPRITE.RIGHT;
            spr_submarine_right.Position = renderer.Position;
            renderer = spr_submarine_right;
        }
        void SpriteDestroyedLeft()
        {
            state = SPRITE.DESTROYED_LEFT;
            spr_submarine_destroyed_left.Position = renderer.Position;
            renderer = spr_submarine_destroyed_left;
        }
        void SpriteDestroyedRight()
        {
            state = SPRITE.DESTROYED_RIGHT;
            spr_submarine_destroyed_right.Position = renderer.Position;
            renderer = spr_submarine_destroyed_right;
        }

        #endregion

        public void OnOctopusCollision(COLLISION_DIRECTION dir)
        {
            switch (dir)
            {
                case COLLISION_DIRECTION.TOP:
                case COLLISION_DIRECTION.BOT:
                case COLLISION_DIRECTION.LEFT:
                case COLLISION_DIRECTION.RIGHT:
                    break;
            }
        }


    }
}
