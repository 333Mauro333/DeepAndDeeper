﻿using SFML.Graphics;
using SFML.Window;


namespace SFML_TEST
{
    abstract class Scene // Molde para hacer las escenas del juego, por eso la clase es abstracta.
    {
        abstract public void Init(); // Para inicializar los objetos y todo

        abstract public void Udpate(float deltaTime); // Para comprobar movimientos, eventos, etc. en cada frame.

        abstract public void Draw(RenderWindow window); // Para dibujar todo.

        abstract public void KeyPressed(Keyboard.Key key);

        abstract public void KeyReleased(Keyboard.Key key);

    }
}
