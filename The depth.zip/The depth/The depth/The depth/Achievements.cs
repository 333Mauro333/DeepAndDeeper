﻿using Deep_And_Deeper;
using Big_Block_Breaker;
using SFML.Graphics;
using SFML.System;
using SFML.Window;
using SFML_TEST;
using System;

namespace Big_Block_Breaker
{
    class Achievements : Scene
    {
        const int size = 4;

        public static bool[] done = new bool[size];
        public static bool firstTime = true;
        // For missions

        public static bool bought = false;
        public static float totalDistance = 0;
        public static int leaveOctopus = 0;
        public static int money = 0;


        static string[] str_achievement = new string[size];
        static string[] str_achievementDescription = new string[size];
        static string[] str_achievementState = new string[size];

        static Text[] txt_achievement = new Text[size];
        static Text[] txt_achievementDescription = new Text[size];
        static Text[] txt_achievementState = new Text[size];

        Sprite back;

        public override void Init()
        {
            back = new Sprite(new Texture("resources/Backgrounds/backgroundAchievements.png"));
            int posX = 25;
            int posY = 30;

            for (int i = 0; i < size; i++)
            {
                txt_achievement[i].Position = new Vector2f(posX, posY);

                posY += 125;
            }

            posY = 60;

            for (int i = 0; i < size; i++)
            {
                txt_achievementDescription[i].Position = new Vector2f(posX, posY);

                posY += 125;
            }

            posY = 100;

            for (int i = 0; i < size; i++)
            {
                txt_achievementState[i].Position = new Vector2f(posX, posY);

                posY += 125;
            }
        }
        public override void Udpate(float deltaTime)
        {
            for (int i = 0; i < size; i++)
            {
                switch (i)
                {
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                        if (done[i])
                        {
                            str_achievementState[i] = "Completado";
                        }
                        else
                        {
                            str_achievementState[i] = "Incompleto";
                        }

                        break;
                }
                switch (i)
                {
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                        txt_achievementState[i].DisplayedString = str_achievementState[i];
                        break;
                }
            }
        }

        public override void Draw(RenderWindow window)
        {
            window.Draw(back);

            for (int i = 0; i < size; i++)
            {
                window.Draw(txt_achievement[i]);
                window.Draw(txt_achievementDescription[i]);
                window.Draw(txt_achievementState[i]);
            }
        }
        public override void KeyPressed(Keyboard.Key key)
        {
            if (key == Keyboard.Key.Enter)
            {
                SceneManager.LoadScene(new Menu());
            }
        }
        public override void KeyReleased(Keyboard.Key key)
        {

        }

        public static void InitAllAchievements()
        {
            for (int i = 0; i < size; i++)
            {
                done[i] = false;
                
                switch (i)
                {
                    case 0:
                        str_achievement[i] = "EXPLORADOR DE OCÉANOS"; // acumular
                        break;

                    case 1:
                        str_achievement[i] = "ANTI AGARRE"; // sacarse los pulpos de encima
                        break;

                    case 2:
                        str_achievement[i] = "RECOLECTOR DE MONEDAS";
                        break;

                    case 3:
                        str_achievement[i] = "PRIMERA ADQUISICION"; // comprar un submarino nuevo
                        break;
                }

                switch (i)
                {
                    case 0:
                        str_achievementDescription[i] = "Acumula un total de 1000m recorridos de profundidad."; // acumular
                        break;

                    case 1:
                        str_achievementDescription[i] = "Suéltate del pulpo un total de 20 veces."; // sacarse los pulpos de encima
                        break;

                    case 2:
                        str_achievementDescription[i] = "Acumula 500 monedas.";
                        break;

                    case 3:
                        str_achievementDescription[i] = "Compra un nuevo submarino."; // comprar un submarino nuevo
                        break;
                }

                switch (i)
                {
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                        if (done[i])
                        {
                            str_achievementState[i] = "Completado";
                        }
                        else
                        {
                            str_achievementState[i] = "Incompleto";
                        }

                        break;
                }
            }
            for (int i = 0; i < size; i++)
            {
                switch (i)
                {
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                        txt_achievement[i] = new Text(str_achievement[i], new Font("resources/Fonts/retro.ttf"));
                        txt_achievementDescription[i] = new Text(str_achievementDescription[i], new Font("resources/Fonts/retro.ttf"));
                        txt_achievementState[i] = new Text(str_achievementState[i], new Font("resources/Fonts/retro.ttf"));

                        txt_achievement[i].CharacterSize = 25;
                        txt_achievementDescription[i].CharacterSize = 22;
                        txt_achievementState[i].CharacterSize = 18;
                        break;
                }
            }
        }
    }
}
