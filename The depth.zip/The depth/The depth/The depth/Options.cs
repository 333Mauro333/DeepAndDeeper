﻿using Big_Block_Breaker;
using SFML.Graphics;
using SFML.System;
using SFML.Window;
using SFML_TEST;

namespace Deep_And_Deeper
{
    class Options : Scene
    {
        public static int optSubmarine = 1;
        public static int coins = 0;

        Sprite back;

        int actualOpt = 1;
        int subOpt = 1;

        Text txt_selectSubmarine;
        Text txt_returnToMenu;

        public override void Init()
        {
            txt_selectSubmarine = new Text("", new Font("resources/Fonts/crkdwno1.ttf"));
            txt_returnToMenu = new Text("", new Font("resources/Fonts/crkdwno1.ttf"));

            back = new Sprite(new Texture("resources/Backgrounds/backgroundMenu.png"));

            InitOptionMenu(txt_selectSubmarine, 230.0f, 100.0f);
            InitOptionMenu(txt_returnToMenu, 190.0f, 400.0f);
        }
        public override void Udpate(float deltaTime)
        {
            UpdateOptionMenu(txt_selectSubmarine, "SUBMARINOS", 1);
            UpdateOptionMenu(txt_returnToMenu, "VOLVER AL MENU", 2);
        }
        public override void Draw(RenderWindow window)
        {
            window.Draw(back);
            window.Draw(txt_selectSubmarine);
            window.Draw(txt_returnToMenu);
        }
        public override void KeyPressed(Keyboard.Key key)
        {
            if (key == Keyboard.Key.Up)
            {
                if (actualOpt > 1)
                {
                    actualOpt--;
                }
            }
            if (key == Keyboard.Key.Down)
            {
                if (actualOpt < 2)
                {
                    actualOpt++;
                }
            }

            if (key == Keyboard.Key.Left)
            {
                if (actualOpt == 1)
                {
                    if (subOpt > 1)
                    {
                        actualOpt--;
                    }
                }
            }
            if (key == Keyboard.Key.Right)
            {
                if (actualOpt == 5)
                {
                    if (subOpt < 5)
                    {
                        actualOpt++;
                    }
                }
            }

            if (key == Keyboard.Key.Enter)
            {
                if (actualOpt == 1)
                {
                    switch (subOpt)
                    {
                        case 1:

                            break;
                    }
                }
                if (actualOpt == 2)
                {
                    SceneManager.LoadScene(new Menu());
                }
            }
        }
        public override void KeyReleased(Keyboard.Key key)
        {

        }

        void InitOptionMenu(Text txt_opt, float posX, float posY)
        {
            txt_opt.Origin = new Vector2f(txt_opt.GetGlobalBounds().Width / 2.0f, txt_opt.GetGlobalBounds().Height / 2.0f);
            txt_opt.CharacterSize = 50;
            txt_opt.Position = new Vector2f(posX, posY);
            txt_opt.FillColor = Color.Magenta;
        }
        void UpdateOptionMenu(Text txt_opt, string text, int bigger = 1)
        {
            switch (actualOpt)
            {
                case 1:
                case 2:
                case 3:
                    if (bigger == actualOpt)
                    {
                        txt_opt.FillColor = Color.White;
                    }
                    else
                    {
                        txt_opt.FillColor = Color.Magenta;
                    }
                    break;
            }

            string CurrPoints = "";
            CurrPoints += text;
            txt_opt.DisplayedString = CurrPoints;
        }
    }
}
