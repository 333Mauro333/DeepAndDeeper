﻿using SFML.Graphics;
using SFML.System;
using SFML.Window;
using SFML.Audio;
using SFML_TEST;
using System;

namespace Big_Block_Breaker
{
    class Enemy
    {
        Random random = new Random();


        #region Sprites and animations

        // General
        Sprite renderer;

        Sprite boxCollision;

        Sprite spr_enemy_left;
        Sprite spr_enemy_right;

        Animation anim_enemy_left;
        Animation anim_enemy_right;

        // Octopus ----------------------------------------------------------------------------------------------------
        Sprite spr_octopus_grabbed;

        Animation anim_octopus_grabbed;

        // Shark ------------------------------------------------------------------------------------------------------
        Sprite spr_shark_crying_left;
        Sprite spr_shark_crying_right;

        Animation anim_shark_crying_left;
        Animation anim_shark_crying_right;

        #endregion

        Sound snd_damage;

        Player target;

        int typeOfEnemy = 0;
        int direction = 0;
        int damage = 10;
        int range = 3;

        float posX = 0;
        float posY = 0;

        float speed = 100;
        float multiplier = 1.0f;

        bool active = true;
        bool escape = false;
        bool grabbed = false;
        bool hit = false;

        SPRITE state;

        enum SPRITE { LEFT, RIGHT, GRABBED, CRYING_LEFT, CRYING_RIGHT };

        public Enemy(int typeOfEnemy, float posX, float posY, int direction, int speed, bool fast, Player target = null)
        {
            switch (typeOfEnemy)
            {
                case 0:
                    // Octopus
                    snd_damage = new Sound(new SoundBuffer("resources/Sfx/pressure.ogg"));

                    spr_enemy_left = new Sprite(new Texture("resources/Sprites/Enemies/octopusLeft.png"));
                    spr_enemy_left.Origin = new Vector2f(42.0f, 50.0f);

                    spr_enemy_right = new Sprite(new Texture("resources/Sprites/Enemies/octopusRight.png"));
                    spr_enemy_right.Origin = new Vector2f(42.0f, 50.0f);

                    spr_octopus_grabbed = new Sprite(new Texture("resources/Sprites/Enemies/octopusGrabbed.png"));
                    spr_octopus_grabbed.Origin = new Vector2f(42.0f, 50.0f);

                    boxCollision = new Sprite(new Texture("resources/Sprites/Enemies/boxOctopus.png"));
                    boxCollision.Origin = new Vector2f(32.0f, 5.0f);
                    break;

                case 1:
                    // Shark
                    snd_damage = new Sound(new SoundBuffer("resources/Sfx/shark_damage.ogg"));

                    spr_enemy_left = new Sprite(new Texture("resources/Sprites/Enemies/sharkLeft.png"));
                    spr_enemy_left.Origin = new Vector2f(62.0f, 29.0f);

                    spr_enemy_right = new Sprite(new Texture("resources/Sprites/Enemies/sharkRight.png"));
                    spr_enemy_right.Origin = new Vector2f(62.0f, 29.0f);

                    spr_shark_crying_left = new Sprite(new Texture("resources/Sprites/Enemies/sharkLeftCrying.png"));
                    spr_shark_crying_left.Origin = new Vector2f(62.0f, 29.0f);

                    spr_shark_crying_right = new Sprite(new Texture("resources/Sprites/Enemies/sharkRightCrying.png"));
                    spr_shark_crying_right.Origin = new Vector2f(62.0f, 29.0f);

                    boxCollision = new Sprite(new Texture("resources/Sprites/Enemies/boxShark.png"));
                    boxCollision.Origin = new Vector2f(59.5f, 22.5f);
                    break;
            }


            renderer = spr_enemy_right;
            boxCollision.Position = new Vector2f(-350.0f, -350.0f);
            state = SPRITE.RIGHT;

            renderer.Position = new Vector2f(posX, posY);
            this.target = target;
            this.direction = direction;
            this.typeOfEnemy = typeOfEnemy;
        }

        public void Update(float deltaTime)
        {
            switch (typeOfEnemy)
            {
                case 0:
                    UpdateOctopus(deltaTime);
                    break;
                case 1:
                    UpdateShark(deltaTime);
                    break;
            }

            boxCollision.Position = renderer.Position;
        }

        public void ResetValues()
        {
            switch (typeOfEnemy)
            {
                case 0:
                    active = false;
                    escape = false;
                    grabbed = false;
                    hit = false;
                    SpriteLeft();
                    break;

                case 1:
                    active = false;
                    escape = false;
                    //SpriteLeft();
                    break;

            }

            active = false;
        }
        public void ActiveEnemy()
        {
            int side = random.Next(4);
            int choice = random.Next(3);
            int posX = 0;
            int posY = 0;

            switch (typeOfEnemy)
            {
                case 0:
                    // Octopus
                    switch (side)
                    {
                        case 0:
                            posX = -100;

                            if (choice == 0)
                            {
                                posY = 150;
                            }
                            else if (choice == 1)
                            {
                                posY = 300;
                            }
                            else
                            {
                                posY = 450;
                            }
                            break;

                        case 1:
                            posX = 900;

                            if (choice == 0)
                            {
                                posY = 150;
                            }
                            else if (choice == 1)
                            {
                                posY = 300;
                            }
                            else
                            {
                                posY = 450;
                            }
                            break;

                        case 2:
                            posY = 700;

                            if (choice == 0)
                            {
                                posX = 200;
                            }
                            else if (choice == 1)
                            {
                                posX = 425;
                            }
                            else
                            {
                                posY = 650;
                            }
                            break;

                        case 3:
                            posY = -100;

                            if (choice == 0)
                            {
                                posX = 200;
                            }
                            else if (choice == 1)
                            {
                                posX = 425;
                            }
                            else
                            {
                                posY = 650;
                            }
                            break;
                    }

                    direction = side;

                    active = true;
                    renderer.Position = new Vector2f(posX, posY);
                    break;

                case 1:
                    // Shark
                    switch (side)
                    {
                        case 0:
                        case 1:
                            posX = -100;

                            if (choice == 0)
                            {
                                posY = 150;
                            }
                            else if (choice == 1)
                            {
                                posY = 300;
                            }
                            else
                            {
                                posY = 450;
                            }
                            break;

                        case 2:
                        case 3:
                            posX = 900;

                            if (choice == 0)
                            {
                                posY = 150;
                            }
                            else if (choice == 1)
                            {
                                posY = 300;
                            }
                            else
                            {
                                posY = 450;
                            }
                            break;
                    }

                    active = true;
                    renderer.Position = new Vector2f(posX, posY);
                    break;
            }
        }

        void UpdateOctopus(float deltaTime)
        {
            if (active)
            {
                if (escape)
                {
                    multiplier = 3.0f;
                }
                else
                {
                    multiplier = 1.0f;
                }

                if (!grabbed)
                {
                    switch (direction)
                    {
                        case 0:
                            // 0 = hacia la derecha.
                            renderer.Position += new Vector2f(speed * multiplier, 0.0f) * deltaTime;
                            SpriteRight();
                            break;

                        case 1:
                            // 1 = hacia la izquierda.
                            renderer.Position += new Vector2f(-speed * multiplier, 0.0f) * deltaTime;
                            SpriteLeft();
                            break;

                        case 2:
                            // 2 = hacia arriba.
                            renderer.Position += new Vector2f(0.0f, -speed * multiplier) * deltaTime;
                            SpriteLeft();
                            break;

                        case 3:
                            // 3 = hacia abajo.
                            renderer.Position += new Vector2f(0.0f, speed * multiplier) * deltaTime;
                            SpriteRight();
                            break;
                    }
                }
                else
                {
                    GetNumberOfFrame();

                    renderer.Position = target.GetRenderer().Position;
                    SpriteGrabbed();

                    if (target.GetMoves() >= 15)
                    {
                        Achievements.leaveOctopus++;
                        InitAnimation();
                        target.SetMoves();
                        target.SetCaptured(false);
                        hit = false;
                        grabbed = false;
                        escape = true;
                    }
                }
            }
            else
            {
                // Reset values

                multiplier = 1.0f;

                escape = false;
                grabbed = false;
            }
        }
        void UpdateShark(float deltaTime)
        {
            if (active)
            {
                if (escape)
                {
                    multiplier = 2.0f;
                }
                else
                {
                    multiplier = 1.0f;
                }

                switch (direction)
                {
                    case 0:
                    case 1:
                        // 0 - 1 = hacia la derecha.
                        if (escape)
                        {
                            SpriteCryingRight();
                        }
                        else
                        {
                            SpriteRight();
                        }
                        renderer.Position += new Vector2f(speed * multiplier, 0.0f) * deltaTime;
                        
                        break;

                    case 2:
                    case 3:
                        // 2 - 3 = hacia la izquierda.
                        if (escape)
                        {
                            SpriteCryingLeft();
                        }
                        else
                        {
                            SpriteLeft();
                        }
                        renderer.Position += new Vector2f(-speed * multiplier, 0.0f) * deltaTime;
                        break;
                }
            }
            else
            {
                multiplier = 1.0f;

                escape = false;
            }
        }

        #region Getters and setters

        public Sprite GetRenderer()
        {
            return renderer;
        }
        public Sprite GetBoxCollision()
        {
            return boxCollision;
        }
        public bool GetEscape()
        {
            return escape;
        }
        public bool GetHit()
        {
            return hit;
        }
        void SetPosition()
        {
            renderer.Position = new Vector2f(posX, posY);
        }
        void SetActive(bool active)
        {
            this.active = active;
        }

        #endregion


        public void InitAnimation()
        {
            int Left = 0;
            int sizeX = 0;
            int sizeY = 0;

            switch (typeOfEnemy)
            {
                case 0:
                    sizeX = 84;
                    sizeY = 101;

                    anim_enemy_left = new Animation(ref spr_enemy_left, Animation.MODE.LOOP);
                    for (int i = 0; i < 5; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                anim_enemy_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 1:
                                anim_enemy_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 2:
                                anim_enemy_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 3:
                                anim_enemy_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 4:
                                anim_enemy_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                        }

                        Left += 84;
                    }
                    Left = 0;

                    anim_enemy_right = new Animation(ref spr_enemy_right, Animation.MODE.LOOP);
                    for (int i = 0; i < 5; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                anim_enemy_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.1));
                                break;
                            case 1:
                                anim_enemy_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.1));
                                break;
                            case 2:
                                anim_enemy_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.1));
                                break;
                            case 3:
                                anim_enemy_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.1));
                                break;
                            case 4:
                                anim_enemy_right.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.1));
                                break;
                        }

                        Left += 84;
                    }
                    Left = 0;

                    anim_octopus_grabbed = new Animation(ref spr_octopus_grabbed, Animation.MODE.LOOP);
                    for (int i = 0; i < 5; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                anim_octopus_grabbed.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.25));
                                break;
                            case 1:
                                anim_octopus_grabbed.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.25));
                                break;
                            case 2:
                                anim_octopus_grabbed.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.25));
                                break;
                            case 3:
                                anim_octopus_grabbed.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.2));
                                break;
                            case 4:
                                anim_octopus_grabbed.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.1));
                                break;
                            case 5:
                                anim_octopus_grabbed.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.1));
                                break;
                            case 6:
                                anim_octopus_grabbed.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.5));
                                break;
                            case 7:
                                anim_octopus_grabbed.AddFrame(new Frame(new IntRect(Left, 0, 84, 101), 0.5));
                                break;
                        }

                        Left += 84;
                    }
                    break;

                case 1:
                    sizeX = 124;
                    sizeY = 58;

                    anim_enemy_left = new Animation(ref spr_enemy_left, Animation.MODE.LOOP);
                    for (int i = 0; i < 5; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                anim_enemy_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 1:
                                anim_enemy_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 2:
                                anim_enemy_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 3:
                                anim_enemy_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 4:
                                anim_enemy_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                        }

                        Left += 124;
                    }
                    Left = 0;

                    anim_enemy_right = new Animation(ref spr_enemy_right, Animation.MODE.LOOP);
                    for (int i = 0; i < 5; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                anim_enemy_right.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 1:
                                anim_enemy_right.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 2:
                                anim_enemy_right.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 3:
                                anim_enemy_right.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 4:
                                anim_enemy_right.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                        }

                        Left += 124;
                    }
                    Left = 0;

                    anim_shark_crying_left = new Animation(ref spr_shark_crying_left, Animation.MODE.LOOP);
                    for (int i = 0; i < 5; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                anim_shark_crying_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 1:
                                anim_shark_crying_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 2:
                                anim_shark_crying_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 3:
                                anim_shark_crying_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 4:
                                anim_shark_crying_left.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                        }

                        Left += 124;
                    }
                    Left = 0;

                    anim_shark_crying_right = new Animation(ref spr_shark_crying_right, Animation.MODE.LOOP);
                    for (int i = 0; i < 5; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                anim_shark_crying_right.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 1:
                                anim_shark_crying_right.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 2:
                                anim_shark_crying_right.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 3:
                                anim_shark_crying_right.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                            case 4:
                                anim_shark_crying_right.AddFrame(new Frame(new IntRect(Left, 0, sizeX, sizeY), 0.1));
                                break;
                        }

                        Left += 124;
                    }
                    break;
            }
        }
        public void UpdateAnimation(float elapsed)
        {
            switch (state)
            {
                case SPRITE.LEFT:
                    anim_enemy_left.Update(elapsed);
                    break;

                case SPRITE.RIGHT:
                    anim_enemy_right.Update(elapsed);
                    break;

                case SPRITE.GRABBED:
                    anim_octopus_grabbed.Update(elapsed);
                    break;

                case SPRITE.CRYING_LEFT:
                    anim_shark_crying_left.Update(elapsed);
                    break;

                case SPRITE.CRYING_RIGHT:
                    anim_shark_crying_right.Update(elapsed);
                    break;
            }
        }
        public void DrawAnimation(RenderWindow window)
        {
            switch (state)
            {
                case SPRITE.LEFT:
                    window.Draw(spr_enemy_left);
                    break;

                case SPRITE.RIGHT:
                    window.Draw(spr_enemy_right);
                    break;

                case SPRITE.GRABBED:
                    window.Draw(spr_octopus_grabbed);
                    break;

                case SPRITE.CRYING_LEFT:
                    window.Draw(spr_shark_crying_left);
                    break;

                case SPRITE.CRYING_RIGHT:
                    window.Draw(spr_shark_crying_right);
                    break;
            }

            //window.Draw(boxCollision);
        }

        #region Sprite modifier

        // General
        void SpriteLeft()
        {
            state = SPRITE.LEFT;
            spr_enemy_left.Position = renderer.Position;
            renderer = spr_enemy_left;
        }
        void SpriteRight()
        {
            state = SPRITE.RIGHT;
            spr_enemy_right.Position = renderer.Position;
            renderer = spr_enemy_right;
        }

        // Octopus
        void SpriteGrabbed()
        {
            state = SPRITE.GRABBED;
            spr_octopus_grabbed.Position = renderer.Position;
            renderer = spr_octopus_grabbed;
        }

        // Shark
        void SpriteCryingLeft()
        {
            state = SPRITE.CRYING_LEFT;
            spr_shark_crying_left.Position = renderer.Position;
            renderer = spr_shark_crying_left;
        }
        void SpriteCryingRight()
        {
            state = SPRITE.CRYING_RIGHT;
            spr_shark_crying_right.Position = renderer.Position;
            renderer = spr_shark_crying_right;
        }
        #endregion

        void GetNumberOfFrame()
        {
            if (anim_octopus_grabbed.GetNumberOfFrame() == 4)
            {
                if (!hit)
                {
                    hit = true;
                    snd_damage.Play();
                    int randomNum = random.Next(range) - (range / 2) + damage;

                    target.SetModHealth(-randomNum);
                }
            }
            else
            {
                hit = false;
            }
        }

        public void OnPlayerCollision(COLLISION_DIRECTION dir)
        {
            switch (dir)
            {
                case COLLISION_DIRECTION.TOP:
                case COLLISION_DIRECTION.BOT:
                case COLLISION_DIRECTION.LEFT:
                case COLLISION_DIRECTION.RIGHT:
                    switch (typeOfEnemy)
                    {
                        case 0:
                            if (!grabbed && !escape)
                            {
                                target.SetCaptured(true);
                                grabbed = true;
                            }
                            break;

                        case 1:
                            if (!escape)
                            {
                                escape = true;
                                snd_damage.Play();

                                if (state == SPRITE.LEFT)
                                {
                                    multiplier = 2.0f;
                                }
                                else if (state == SPRITE.RIGHT)
                                {
                                    multiplier = 2.0f;
                                }

                                int randomNum = random.Next(range) - (range / 2) + damage * 3;

                                target.SetModHealth(-randomNum);
                            }
                            break;
                    }
                    break;
            }
        }
    }
}
