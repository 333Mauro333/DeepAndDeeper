﻿using Deep_And_Deeper;
using SFML.Graphics;
using SFML.System;
using SFML.Window;
using SFML_TEST;
using System;

namespace Big_Block_Breaker
{
    class Menu : Scene
    {
        Sprite back;

        int actualOpt = 1;

        Text txt_play;
        Text txt_options;
        Text txt_achievements;

        public override void Init()
        {
            if (Achievements.firstTime)
            {
                Achievements.firstTime = false;
                Achievements.InitAllAchievements();
            }

            txt_play = new Text("", new Font("resources/Fonts/crkdwno1.ttf"));
            txt_options = new Text("", new Font("resources/Fonts/crkdwno1.ttf"));
            txt_achievements = new Text("", new Font("resources/Fonts/crkdwno1.ttf"));

            back = new Sprite(new Texture("resources/Backgrounds/backgroundMenu.png"));

            InitOptionMenu(txt_play, 320.0f, 100.0f);
            InitOptionMenu(txt_options, 275.0f, 200.0f);
            InitOptionMenu(txt_achievements, 315.0f, 300.0f);
        }
        public override void Udpate(float deltaTime)
        {
            UpdateOptionMenu(txt_play, "JUGAR", 1);
            UpdateOptionMenu(txt_options, "OPCIONES", 2);
            UpdateOptionMenu(txt_achievements, "LOGROS", 3);
        }
        public override void Draw(RenderWindow window)
        {
            window.Draw(back);
            window.Draw(txt_play);
            window.Draw(txt_options);
            window.Draw(txt_achievements);
        }
        public override void KeyPressed(Keyboard.Key key)
        {
            if (key == Keyboard.Key.Up)
            {
                if (actualOpt > 1)
                {
                    actualOpt--;
                }
            }
            if (key == Keyboard.Key.Down)
            {
                if (actualOpt < 3)
                {
                    actualOpt++;
                }
            }

            if (key == Keyboard.Key.Enter)
            {
                if (actualOpt == 1)
                {
                    SceneManager.LoadScene(new Gameplay());
                }
                if (actualOpt == 2)
                {
                    SceneManager.LoadScene(new Options());
                }
                if (actualOpt == 3)
                {
                    SceneManager.LoadScene(new Achievements());
                }
            }
        }
        public override void KeyReleased(Keyboard.Key key)
        {

        }

        void InitOptionMenu(Text txt_opt, float posX, float posY)
        {
            txt_opt.Origin = new Vector2f(txt_opt.GetGlobalBounds().Width / 2.0f, txt_opt.GetGlobalBounds().Height / 2.0f);
            txt_opt.CharacterSize = 50;
            txt_opt.Position = new Vector2f(posX, posY);
            txt_opt.FillColor = Color.Magenta;
        }
        void UpdateOptionMenu(Text txt_opt, string text, int bigger = 1)
        {
            switch (actualOpt)
            {
                case 1:
                case 2:
                case 3:
                    if (bigger == actualOpt)
                    {
                        txt_opt.FillColor = Color.White;
                    }
                    else
                    {
                        txt_opt.FillColor = Color.Magenta;
                    }
                    break;
            }

            string CurrPoints = "";
            CurrPoints += text;
            txt_opt.DisplayedString = CurrPoints;
        }
    }
}
