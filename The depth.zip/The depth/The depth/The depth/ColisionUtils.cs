﻿using System;
using SFML.Window;
using SFML.Graphics;
using SFML.System;
using SFML.Audio;

namespace SFML_TEST
{
    public enum COLLISION_DIRECTION { LEFT, RIGHT, TOP, BOT }

    class ColisionUtils
    {
        public static bool CheckCollision(Sprite spriteA, Sprite spriteB, ref COLLISION_DIRECTION dir)
        {
            FloatRect rectA = spriteA.GetGlobalBounds();
            FloatRect rectB = spriteB.GetGlobalBounds();

            float aRight = rectA.Left + rectA.Width;
            float bRight = rectB.Left + rectB.Width;
            float aDown = rectA.Top + rectA.Height;
            float bDown = rectB.Top + rectB.Height;


            if (aRight >= rectB.Left)
            {
                if (rectA.Left <= bRight)
                {
                    if (rectA.Top <= bDown)
                    {
                        if (aDown >= rectB.Top)
                        {
                            if (CollisionOnLeft(rectA, rectB))
                            {
                                dir = COLLISION_DIRECTION.LEFT;
                                return true;
                            }

                            if (CollisionOnRight(rectA, rectB))
                            {
                                dir = COLLISION_DIRECTION.RIGHT;
                                return true;
                            }

                            if (CollisionOnTop(rectA, rectB))
                            {
                                dir = COLLISION_DIRECTION.TOP;
                                return true;
                            }

                            if (CollisionOnBot(rectA, rectB))
                            {
                                dir = COLLISION_DIRECTION.BOT;
                                return true;
                            }
                        }
                    }
                }
            }

            return false;
        }

        private static bool CollisionOnLeft(FloatRect RectA, FloatRect RectB)
        {
            float aRight = RectA.Left + RectA.Width;
            float bRight = RectB.Left + RectB.Width;

            if (RectB.Left < RectA.Left && RectB.Left < (RectA.Left + aRight) && bRight < aRight)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private static bool CollisionOnRight(FloatRect RectA, FloatRect RectB)
        {
            float aRight = RectA.Left + RectA.Width;
            float bRight = RectB.Left + RectB.Width;

            if (RectA.Left < RectB.Left && RectA.Left < (RectB.Left + bRight) && aRight < bRight)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private static bool CollisionOnTop(FloatRect RectA, FloatRect RectB)
        {
            float aDown = RectA.Top + RectA.Height;
            float bDown = RectB.Top + RectB.Height;

            if (RectB.Top < RectA.Top && RectB.Top < (RectA.Top + aDown) && bDown < aDown)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private static bool CollisionOnBot(FloatRect RectA, FloatRect RectB)
        {
            float aDown = RectA.Top + RectA.Height;
            float bDown = RectB.Top + RectB.Height;

            if (RectA.Top < RectB.Top && RectA.Top < (RectB.Top + bDown) && aDown < bDown)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}