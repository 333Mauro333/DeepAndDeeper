﻿using SFML.Graphics;
using SFML.System;

namespace SFML_TEST
{
    class FadeInFadeOut
    {
        Texture tex;
        Sprite renderer;
        Animation animation;
        bool Fade = false;

        public FadeInFadeOut(int sprite)
        {
            if (sprite == 0)
            {
                tex = new Texture("resources/Fade/FadeIn.png");
            } // FadeIn
            else
            {
                tex = new Texture("resources/Fade/FadeOut.png");
            } // FadeOut

            renderer = new Sprite(tex);
            renderer.Position = new Vector2f(300, 300);

            animation = new Animation(ref renderer, Animation.MODE.ONCE);
            int left = 0;
            int top = 0;

            for (int i = 0; i < 20; i++)
            {
                animation.AddFrame(new Frame(new IntRect(left, top, 150, 100), 0.05f));

                left += 150;
            }
        }
        public void GetAnimation(double elapsed)
        {
            animation.Update(elapsed);

            if (!Fade)
            {
                Fade = true;
                LoadAnimation(tex, renderer);
            }
        }
        public void LoadAnimation(Texture tex, Sprite renderer)
        {
            this.tex = tex;
            this.renderer = renderer;

            animation = new Animation(ref renderer, Animation.MODE.ONCE);
            int left = 0;
            int top = 0;

            for (int i = 0; i < 20; i++)
            {
                animation.AddFrame(new Frame(new IntRect(left, top, 150, 100), 0.05f));

                left += 150;
            }
        }
        public void SetPositions(float X, float Y)
        {
            renderer.Position = new Vector2f(X, Y);
        }
        public Sprite GetRenderer()
        {
            return renderer;
        }
        public Texture GetTexture()
        {
            return tex;
        }
    }
}
